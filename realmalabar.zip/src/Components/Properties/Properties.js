import React from 'react'

function Properties() {
    return (
        <section className="thoughts container-fluid bg-light">
            <div className="mindset">
                <div className="contents text-center">
                    <h6 className=""><span className="px-2"><img src="./assets/minus .png" alt=""/></span>  Properties <span className="px-2"><img src="./assets/minus .png" alt=""/></span></h6>
                    <h2 className="spFont">Recently Added</h2>
                    <p className="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis molestias temporibus<br/> nesciunt incidunt  aliquam quasi quidem ipsum laboriosam deserunt officiis!</p>
                </div>
            </div>
            <div className="container">
                <div className="row grids">
                    <div className="col-md-3 property-list">
                      <a href="./property-details.html"> 
                      <div className="card my-4">
                          <div className="img-container">
                         
                                                 
                             <span className="for-sale">For sale</span>                                 
                             <img src="./assets/product.jpg" className="img-fluid"/>

                          </div>
                          <div className="product-detail-container">
                            <div className="d-block ">
                              <h3 className="mb-0 spFont">Good Life Property Ltd</h3> 
                             
                              <span className="location"><i className="fa fa-map-marker" aria-hidden="true"></i>970 Torriford street ,Torrington 5676</span>
                            
                          </div>
                          <div className="d-flex aminty"> 
                            <div className="births">
                              <span className="text-muted">4 </span>
                            </div>
                            <div className="births">
                             <span className="text-muted">4 </span>
                           </div>
                           <div className="births">
                             <span  className="text-muted">4 </span>
                           </div>                   
                          </div>
                          <div className="price">
                         
                            <h5><i>&#8377;</i>11,250</h5>
                           </div>            
                          </div>
                      </div>
                    </a>
                  </div>
                  
                  <div className="col-md-3 property-list">
                    <a href="./property-details.html"> 
                    <div className="card my-4">
                        <div className="img-container">
                       
                                               
                           <span className="for-sale">For sale</span>                                 
                           <img src="./assets/product.jpg" className="img-fluid"/>

                        </div>
                        <div className="product-detail-container">
                          <div className="d-block ">
                            <h3 className="mb-0 spFont">Good Life Property Ltd</h3> 
                           
                            <span className="location"><i className="fa fa-map-marker" aria-hidden="true"></i>970 Torriford street ,Torrington 5676</span>
                          
                        </div>
                        <div className="d-flex aminty"> 
                          <div className="births">
                            <span className="text-muted">4 </span>
                          </div>
                          <div className="births">
                           <span className="text-muted">4 </span>
                         </div>
                         <div className="births">
                           <span  className="text-muted">4 </span>
                         </div>                   
                        </div>
                        <div className="price">
                       
                          <h5><i>&#8377;</i>11,250</h5>
                         </div>            
                        </div>
                    </div>
                  </a>
                </div>
                <div className="col-md-3 property-list">
                  <a href="./property-details.html"> 
                  <div className="card my-4">
                      <div className="img-container">
                     
                                             
                         <span className="for-sale">For sale</span>                                 
                         <img src="./assets/product.jpg" className="img-fluid"/>

                      </div>
                      <div className="product-detail-container">
                        <div className="d-block ">
                          <h3 className="mb-0 spFont">Good Life Property Ltd</h3> 
                         
                          <span className="location"><i className="fa fa-map-marker" aria-hidden="true"></i>970 Torriford street ,Torrington 5676</span>
                        
                      </div>
                      <div className="d-flex aminty"> 
                        <div className="births">
                          <span className="text-muted">4 </span>
                        </div>
                        <div className="births">
                         <span className="text-muted">4 </span>
                       </div>
                       <div className="births">
                         <span  className="text-muted">4 </span>
                       </div>                   
                      </div>
                      <div className="price">
                     
                        <h5><i>&#8377;</i>11,250</h5>
                       </div>            
                      </div>
                  </div>
                </a>
              </div>
              <div className="col-md-3 property-list">
                <a href="./property-details.html"> 
                <div className="card my-4">
                    <div className="img-container">
                   
                                           
                       <span className="for-sale">For sale</span>                                 
                       <img src="./assets/product.jpg" className="img-fluid"/>

                    </div>
                    <div className="product-detail-container">
                      <div className="d-block ">
                        <h3 className="mb-0 spFont">Good Life Property Ltd</h3> 
                       
                        <span className="location"><i className="fa fa-map-marker" aria-hidden="true"></i>970 Torriford street ,Torrington 5676</span>
                      
                    </div>
                    <div className="d-flex aminty"> 
                      <div className="births">
                        <span className="text-muted">4 </span>
                      </div>
                      <div className="births">
                       <span className="text-muted">4 </span>
                     </div>
                     <div className="births">
                       <span  className="text-muted">4 </span>
                     </div>                   
                    </div>
                    <div className="price">
                   
                      <h5><i>&#8377;</i>11,250</h5>
                     </div>            
                    </div>
                </div>
              </a>
            </div>
                   </div>
            </div>            
        </section>
    )
}

export default Properties
