import React from 'react'

function PropertyBanner() {
    return (
        <img src="./Assets/cover.jpg" alt="loading"/>
    )
}

export default PropertyBanner
