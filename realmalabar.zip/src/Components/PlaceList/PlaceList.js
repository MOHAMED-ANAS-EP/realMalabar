import React from 'react'

function PlaceList() {
    return (
        <div className="col-md-3">
              <ul className="location-list">
                <li>Arakkinar</li>
                  <li> Areekkad</li>
                    <li>Atholi road</li>
                      <li>Azhinjilam Ramanattukara</li>
                        <li> Beypore</li>
                          <li> Calicut city</li>
                            <li>Chalappuram</li>
                              <li>Chelavoor</li>
                                <li>Cherukulam</li>
                                  <li> Cheruvannur</li>
                                    <li> Cheruvatta</li>
                                      <li>Chettikulam</li>
                                        <li>Chevarambalam</li>
                                          <li> Chevayoor</li>
                                            <li> Civilstaion</li>
                                              <li>Civilstation</li>
                                                <li>Easthill</li>
                                                  <li>Elathur</li>
                                                    <li>Eranhipalam</li>
                                                      <li>Feroke</li>
                                                        <li> Govindapuram</li>
                                                          <li>Kakkodi</li>
                                                            <li>Kakkur</li>
                                                              <li>Kallai</li>
              </ul>

            </div>
    )
}

export default PlaceList
