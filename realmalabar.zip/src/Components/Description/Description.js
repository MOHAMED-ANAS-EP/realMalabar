import React from 'react'

function Description() {
    return (
        <div className="boxShadow description">
        <h3 className="spFont text-left">Property Description</h3>
         <p className="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit provident vero modi esse voluptatum! Quibusdam dolore natus iusto vel cumque eaque commodi accusantium perspiciatis fugiat. Doloribus, </p>       
        </div>
    )
}

export default Description
