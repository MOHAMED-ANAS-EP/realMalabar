import React from 'react'

function MakeCall() {
    return (
            <div className="col-md-4  froms">
                <h5><i>&#8377;</i> 245,657.00</h5>
                
                <a  href="tel:9447193424" className="calling"><i className="bi bi-telephone"></i>  Make a Call</a>
                <a className="watsup top-wp" href="https://wa.me/9447193424"> </a>
            </div>
    )
}

export default MakeCall
