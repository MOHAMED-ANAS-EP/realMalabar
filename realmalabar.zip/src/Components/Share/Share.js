import React from 'react'

function Share() {
    return (
        <div className="boxShadow share"> 
        <span className="share-text"> Share:</span>
        <span className="share-btn">   </span>
        <span className="share-fb">   </span>
        <span className="share-wp">   </span>
        <span className="share-ins">   </span>
        </div>
    )
}

export default Share
