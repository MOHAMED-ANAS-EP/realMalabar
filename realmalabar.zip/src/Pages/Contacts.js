import React from 'react'
import Directions from '../Components/Directions/Directions'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import SendMessage from '../Components/SendMesage/SendMessage'

function Contacts() {
    return (
       <div>
        <Header/>
        <SendMessage/>
        <Directions/>
        <Footer/>
       </div>
    )
}

export default Contacts
