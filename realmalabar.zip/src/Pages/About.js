import React from 'react'
import AboutUs from '../Components/AboutUs/AboutUs'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import MindSet from '../Components/MindSet/MindSet'

function About() {
    return (
       <div>
        <Header/>
        <AboutUs/>
        <MindSet/>
        <Footer/>
       </div>

    )
}

export default About
