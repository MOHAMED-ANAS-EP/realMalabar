import React from 'react'
import Banner from '../Components/Banner/Banner'
import CallToAction from '../Components/CallToAction/CallToAction'
import FindOut from '../Components/FindOut/FindOut'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import HomeAbout from '../Components/HomeAbout/HomeAbout'
import Properties from '../Components/Properties/Properties'

function Home() {
    return (
      <div>       
        <Header/>
        <Banner/>
        <HomeAbout/>
        <Properties/>
        <FindOut/>
        <CallToAction/>
        <Footer/>
      </div>
    )
}

export default Home
