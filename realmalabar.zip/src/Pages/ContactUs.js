import React from 'react'
import ContactForm from '../Components/ContactForms/ContactForms'
import Footer from '../Components/Footer/Footer'
import Header from '../Components/Header/Header'
import Location from '../Components/Location/Location'



function ContactUs() {
    return (
       <>
         <Header/>
         <ContactForm/>
         <Location/>
         <Footer/>
       </>
    )
}

export default ContactUs
